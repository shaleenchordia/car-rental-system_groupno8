package org.carrental;

public class Constants {
    public static Database db;
}