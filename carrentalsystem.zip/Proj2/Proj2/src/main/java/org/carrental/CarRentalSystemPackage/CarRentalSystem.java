package org.carrental.CarRentalSystemPackage;

import org.carrental.CarPackage.Car;
import org.carrental.Constants;
import org.carrental.CustomerPackage.Customer;
import org.carrental.RentalPackage.Rental;

import java.util.Scanner;

public class CarRentalSystem {
    public static Car[] cars = new Car[10];
    public static Customer[] customers = new Customer[100];
    public static Rental[] rentals = new Rental[100];

    public static int n_cars = 0;
    public static int n_customers = 0;
    public static int n_rentals = 0;

    public CarRentalSystem() {
        cars = Constants.db.getCars();
        customers = Constants.db.getCustomers();
        rentals = Constants.db.getRentals();
    }

    public Customer addCustomer(String customerName) {
        for (Customer customer : customers) {
            if (customerName.equals(customer.getName())) {
                return customer;
            }
        }

        return Constants.db.createCustomer(customerName);
    }

    public void rentCar(Car car, Customer customer, int days) {
        if (car.isAvailable()) {
            car.rent();
            Constants.db.createRental(new Rental(car, customer, days, true));
        } else {
            System.out.println("Car is not available for rent.");
        }
    }

    public void returnCar(Car car) {
        car.returnCar();
        int rentalToRemove = -1;

        for (int i = 0; i < n_rentals; i++) {
            if (rentals[i].getIsActive() && rentals[i].getCar().getCarId() == car.getCarId()) {
                rentalToRemove = i;
                break;
            }
        }
        if (rentalToRemove != -1) {
            rentals[rentalToRemove].setIsActive(false);
            Constants.db.updateRental(rentals[rentalToRemove]);
            for (int i=rentalToRemove+1; i<n_rentals; i++) {
                rentals[i-1] = rentals[i];
            }
            n_rentals--;
        } else {
            System.out.println("Car was not rented.");
        }
    }

    public void Heading() {
        System.out.println("                  ***************************************************\n");
        System.out.println("                  *            WELCOME TO AIRCAR RENTAL             *\n");
        System.out.println("                  ***************************************************\n");
    }

    public void segments() {
        System.out.println("\n---------------Premium Segments---------------");
        System.out.println("1. Mercedes S-class - ₹4000 per day");
        System.out.println("2. Audi A4 - ₹3500 per day");
        System.out.println("3. Toyota Fortuner - ₹3000 per day");
        System.out.println("---------------Basic Segments---------------");
        System.out.println("4. Hyundai Verna - ₹2500 per day");
        System.out.println("5. Ford Aspire - ₹1500 per day");
        System.out.println("6. Nissan Terrano - ₹2000 per day");
        System.out.println("---------------E-V Segments---------------");
        System.out.println("7. Tesla Model 3 - ₹3000 per day");
        System.out.println("8. Nissan Leaf - ₹1000 per day");
        System.out.println("9. Tata Tiago EV - ₹500 per day");
    }

    public void menu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("=========== AirCar Rental System ============\n");
            System.out.println("1. Rent a Car");
            System.out.println("2. Return a Car");
            System.out.println("3. Show rented cars for a customer");
            System.out.println("4. Exit\n");
            System.out.print("Enter your choice by pressing the Id no. : ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 1) {
                System.out.println("\n=========== Rent a Car ============\n");
                System.out.print("Enter your name: ");
                String customerName = scanner.nextLine();

                System.out.println("\nAvailable Cars segments: \n");
                segments();
                System.out.print("\nEnter the car ID you want to rent: ");
                int carChoice = scanner.nextInt();
                scanner.nextLine();

                System.out.print("Enter the number of days for rental: ");
                int rentalDays = scanner.nextInt();
                scanner.nextLine();

                Customer newCustomer = addCustomer(customerName);

                Car selectedCar = null;
                for (Car car : cars) {
                    int id = Integer.parseInt(car.getCarId());
                    if (car.isAvailable() && carChoice == id) {
                        selectedCar = car;
                        break;
                    }
                }

                if (selectedCar == null) {
                    System.out.println("\nInvalid car selection or car not available for rent.");
                    continue;

                }
                double totalPrice = selectedCar.calculatePrice(rentalDays);
                System.out.println("\n== Rental Information ==\n");
                System.out.println("Customer ID: " + newCustomer.getCustomerId());
                System.out.println("Customer Name: " + newCustomer.getName());
                System.out.println("Car: " + selectedCar.getBrand() + " " + selectedCar.getModel());
                System.out.println("Rental Days: " + rentalDays);
                System.out.printf("Total Price: ₹%.2f%n", totalPrice);

                System.out.print("\nConfirm rental (Y/N): ");
                String confirm = scanner.nextLine();

                if (confirm.equalsIgnoreCase("Y")) {
                    rentCar(selectedCar, newCustomer, rentalDays);
                    System.out.println("\nCar rented successfully.\n");
                } else {
                    System.out.println("\nRental canceled.");
                }
            } else if (choice == 2) {
                System.out.println("\n======== Return a Car ========\n");
                for (Car rentedCar : cars) {
                    if (rentedCar == null || rentedCar.isAvailable()) continue;

                    System.out.println(rentedCar.getCarId() + " - " + rentedCar.getBrand() + " " + rentedCar.getModel());
                }
                System.out.print("Enter the car ID you want to return: ");
                int carChoice = scanner.nextInt();
                scanner.nextLine();

                Rental deal = null;
                for (Rental ren : rentals) {
                    if (ren == null) continue;

                    int id = Integer.parseInt(ren.getCar().getCarId());
                    if (ren.getIsActive() && id == carChoice) {
                        deal = ren;
                        break;
                    }
                }

                if (deal == null) {
                    System.out.println("Invalid car ID or car is not rented.");
                    continue;
                }

                Car carToReturn = deal.getCar();
                Customer customer = deal.getCustomer();

                returnCar(carToReturn);
                System.out.println("Car returned successfully by " + customer.getName());
                
            } else if (choice == 3) {
                System.out.println("\n========== Show Rented Cars ==========\n");
                System.out.print("Enter the customer name: ");
                String customerName = scanner.nextLine();

                System.out.println("Rented cars for " + customerName + ":\n");

                int n_deals = 0;
                for (Rental deal : rentals) {
                    if (deal == null || !deal.getCustomer().getName().equals(customerName)) continue;

                    n_deals++;
                    Car rentedCar = deal.getCar();
                    System.out.println(rentedCar.getCarId() + " - " + rentedCar.getBrand() + " " + rentedCar.getModel());
                }

                if (n_deals == 0) {
                    System.out.println(customerName + " has not rented any cars yet!");
                    continue;
                }
            } else if (choice == 4) {
                break;
            } else {
                System.out.println("Invalid choice. Please enter a valid option.");
            }
        }

        System.out.println("\nThank you for using the Car Rental System!");
        scanner.close();
    }
}