package org.carrental.RentalPackage;

import org.carrental.CarPackage.Car;
import org.carrental.CustomerPackage.Customer;

public class Rental {

    private int id;
    private Car car;
    private Customer customer;
    private int days;
    
    private boolean isActive;
    
    public Rental(int id, Car car, Customer customer, int days, boolean isActive) {
        this.id = id;
        this.car = car;
        this.customer = customer;
        this.days = days;
        this.isActive = isActive;
    }

    public Rental(Car car, Customer customer, int days, boolean isActive) {
        this.car = car;
        this.customer = customer;
        this.days = days;
        this.isActive = isActive;
    }

    public int getId() {
        return id;
    }
    public Car getCar() {
        return car;
    }

    public Customer getCustomer() {
        return customer;
    }

    public int getDays() {
        return days;
    }

    public boolean getIsActive() { return isActive; }
    public void setIsActive(boolean val) { isActive = val; }

}
