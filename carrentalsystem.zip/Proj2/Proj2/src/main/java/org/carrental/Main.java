package org.carrental;

import org.carrental.CarRentalSystemPackage.CarRentalSystem;

public class Main {
    public static void main(String[] args) {

        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
        Constants.db = new Database();
        Constants.db.connect();

        CarRentalSystem rentalSystem = new CarRentalSystem();

        rentalSystem.Heading();
        rentalSystem.menu();
    }
}