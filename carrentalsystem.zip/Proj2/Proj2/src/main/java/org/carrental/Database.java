package org.carrental;

import org.carrental.CarPackage.Car;
import org.carrental.CustomerPackage.Customer;
import org.carrental.RentalPackage.Rental;
import static org.carrental.CarRentalSystemPackage.CarRentalSystem.*;

import java.sql.*;


public class Database {

    public Connection conn = null;

    public Database() {}

    public void connect() {
        try {

            // db parameters
            String url = "jdbc:sqlite:C:\\Users\\Hi\\Desktop\\java\\Proj2\\Proj2\\src\\main\\java\\org\\carrental\\cars.db";
            // create a connection to the database

            this.conn = DriverManager.getConnection(url);
            System.out.println("Connection to SQLite has been established.");

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public Car[] getCars() {

        if (n_cars != 0) return cars;

        try {
            Statement stmt = conn.createStatement();
            ResultSet resultSet = stmt.executeQuery("SELECT * FROM Cars");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String model = resultSet.getString("Model");
                String brand = resultSet.getString("Brand");
                double basePricePerDay = resultSet.getDouble("basePricePerDay");
                boolean isAvailable = resultSet.getBoolean("isAvailable");
                
                
                cars[n_cars++] = new Car(Integer.toString(id), brand, model, basePricePerDay, isAvailable);
            }

            // Close resources
            resultSet.close();
            stmt.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return cars;
    }

    public Customer[] getCustomers() {

        if (n_customers != 0) return customers;

        try {
            Statement stmt = conn.createStatement();
            ResultSet resultSet = stmt.executeQuery("SELECT * FROM Customers");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("Name");
                customers[n_customers++] = new Customer(Integer.toString(id), name);
            }

            // Close resources
            resultSet.close();
            stmt.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return customers;
    }

    public Rental[] getRentals() {

        if (n_rentals != 0) return rentals;

        try {
            Statement stmt = conn.createStatement();
            ResultSet resultSet = stmt.executeQuery("SELECT * FROM Rentals");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                int customerId = resultSet.getInt("customerID");
                int carId = resultSet.getInt("carID");
                int days = resultSet.getInt("days");
                boolean isActive = resultSet.getBoolean("isActive");

                Car currCar = null;
                for (Car car : cars) {
                    if (Integer.parseInt(car.getCarId()) == carId) {
                        currCar = car;
                        break;
                    }
                }
                Customer currCustomer = null;
                for (Customer customer : customers) {
                    if (Integer.parseInt(customer.getCustomerId()) == customerId) {
                        currCustomer = customer;
                        break;
                    }
                }
                rentals[n_rentals++] = new Rental(id, currCar, currCustomer, days, isActive);
            }

            // Close resources
            resultSet.close();
            stmt.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return rentals;
    }

    public void updateCar(Car car) {
        String sql = "UPDATE Cars SET isAvailable = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, car.isAvailable() ? 1 : 0);
            pstmt.setInt(2, Integer.parseInt(car.getCarId()));

            int rowsUpdated = pstmt.executeUpdate();
            System.out.println("Rows updated: " + rowsUpdated);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public void updateRental(Rental rental) {
        String sql = "UPDATE Rentals SET isActive = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, rental.getIsActive() ? 1 : 0);
            pstmt.setInt(2, rental.getId());

            int rowsUpdated = pstmt.executeUpdate();
            System.out.println("Rows updated: " + rowsUpdated);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public Customer createCustomer(String customerName) {
        String query = "INSERT INTO Customers (name) VALUES (?)";

        try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
            preparedStatement.setString(1, customerName);

            preparedStatement.executeUpdate();
            ResultSet resultSet = preparedStatement.getGeneratedKeys();

            while (resultSet.next()) {
                int id = resultSet.getInt(1);

                customers[n_customers++] = new Customer(Integer.toString(id), customerName);
            }
            System.out.println("Customer created successfully!");
            return customers[n_customers - 1];

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void createRental(Rental rental) {
        String query = "INSERT INTO Rentals (carID, customerID, isActive, days) VALUES (?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
            preparedStatement.setInt(1, Integer.parseInt(rental.getCar().getCarId()));
            preparedStatement.setInt(2, Integer.parseInt(rental.getCustomer().getCustomerId()));
            preparedStatement.setBoolean(3, rental.getIsActive());
            preparedStatement.setInt(4, rental.getDays());

            preparedStatement.executeUpdate();
            ResultSet resultSet = preparedStatement.getGeneratedKeys();
            while (resultSet.next()) {
                int id = resultSet.getInt(1);


                rentals[n_rentals++] = new Rental(id, rental.getCar(), rental.getCustomer(), rental.getDays(), rental.getIsActive());
                System.out.println("Rental created successfully!");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}